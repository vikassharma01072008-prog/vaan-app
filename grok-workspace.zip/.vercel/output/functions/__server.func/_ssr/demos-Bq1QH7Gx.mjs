import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Car, D as Activity, E as BedDouble, T as BookOpen, _ as Gem, a as Share2, c as Plane, g as GraduationCap, h as Hospital, i as Star, m as House, o as Scissors, t as UtensilsCrossed, w as Building2, y as Dumbbell } from "../_libs/lucide-react.mjs";
import { n as DEMO_GROUPS, t as DEMOS } from "./content-C5HRfteh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/demos-Bq1QH7Gx.js
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	utensils: UtensilsCrossed,
	dumbbell: Dumbbell,
	bed: BedDouble,
	scissors: Scissors,
	graduation: GraduationCap,
	star: Star,
	share: Share2,
	hospital: Hospital,
	gem: Gem,
	building: Building2,
	home: House,
	car: Car,
	book: BookOpen,
	activity: Activity,
	plane: Plane
};
function DemoIcon({ name, className = "size-7" }) {
	const Icon = ICONS[name];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className,
		strokeWidth: 1.7
	});
}
function Demos() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex flex-1 flex-col px-5 pb-8 pt-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "rise font-display text-2xl font-extrabold tracking-brand text-gold",
			children: "LIVE DEMOS"
		}), DEMO_GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-7",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xs font-semibold tracking-brand text-muted",
				children: group.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid grid-cols-2 gap-3",
				children: DEMOS.filter((demo) => demo.group === group.id).map((demo) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "rise",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/demos/$slug",
						params: { slug: demo.slug },
						className: "flex min-h-36 flex-col items-center justify-center gap-3 rounded-xl bg-card px-3 py-5 text-center shadow-card transition-transform duration-150 ease-out active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-12 items-center justify-center rounded-lg text-gold shadow-gold",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoIcon, { name: demo.icon })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-semibold text-gold",
							children: demo.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block text-xs text-muted",
							children: demo.subtitle
						})] })]
					})
				}, demo.slug))
			})]
		}, group.id))]
	});
}
//#endregion
export { Demos as component };
