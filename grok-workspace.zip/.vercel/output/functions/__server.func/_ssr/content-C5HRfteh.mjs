//#region node_modules/.nitro/vite/services/ssr/assets/content-C5HRfteh.js
var PHONE_DISPLAY = "9671163712";
var PHONE_TEL = "+919671163712";
var WHATSAPP_URL = "https://wa.me/919671163712?text=" + encodeURIComponent("Hi VAAN, I want to know more about your services.");
var INSTAGRAM_URL = "https://instagram.com/vaa_enterprises";
var INSTAGRAM_HANDLE = "@vaa_enterprises";
var LOCATION = "Karnal, Haryana";
var TAGLINE = "Vision · Automation · Advancement · Network";
var HOME_DESCRIPTION = "Premium websites and QR systems for restaurants, hotels, gyms, academies and modern businesses.";
var HOME_STATS = [
	{
		value: "15+",
		label: "Demos"
	},
	{
		value: "24h",
		label: "Response"
	},
	{
		value: "₹0",
		label: "Setup"
	}
];
var SERVICES = [
	{
		slug: "websites",
		code: "01",
		name: "Websites",
		short: "Custom business websites built to rank, convert and look premium.",
		summary: "Mobile-first sites for local and global businesses — fast, searchable, and built to turn visitors into WhatsApp chats and booked jobs.",
		startingAt: "₹4,999",
		packages: [
			{
				name: "Basic",
				price: "₹4,999",
				note: "Launch-ready",
				features: [
					"1–3 page mobile-first site",
					"WhatsApp & call buttons",
					"Google Maps pin",
					"Live in a few days"
				]
			},
			{
				name: "Starter",
				price: "₹11,999",
				note: "Small business",
				features: [
					"Up to 5 pages",
					"Contact form",
					"Basic SEO setup",
					"Analytics connected"
				]
			},
			{
				name: "Business",
				price: "₹19,999",
				note: "Most chosen",
				features: [
					"Up to 10 pages",
					"Booking or enquiry flow",
					"On-page SEO",
					"30 days of tweaks"
				]
			},
			{
				name: "Professional",
				price: "₹29,999",
				note: "Growth brand",
				features: [
					"Custom sections & layout",
					"Blog or gallery",
					"Speed + SEO pass",
					"Priority revisions"
				]
			},
			{
				name: "Premium",
				price: "₹59,999",
				note: "Commerce & portals",
				features: [
					"E-commerce or client portal",
					"Custom design system",
					"Integrations on request",
					"Launch support window"
				]
			},
			{
				name: "Enterprise",
				price: "₹1,00,000+",
				note: "Multi-location",
				features: [
					"Multi-branch or multi-language",
					"Custom integrations",
					"Dedicated support",
					"Scoped to your stack"
				]
			}
		]
	},
	{
		slug: "qr",
		code: "02",
		name: "QR Systems",
		short: "QR menus, hotel concierge, gym check-in, academy portals and more.",
		summary: "One scan, instant info. Update menus, rooms, classes and bookings without reprinting a thing — the system works while you sleep.",
		startingAt: "₹999+",
		packages: [
			{
				name: "Restaurant",
				price: "₹2,999–4,999",
				note: "QR menu",
				features: [
					"Digital menu with categories",
					"Instant item updates",
					"WhatsApp ordering link",
					"Print-ready QR card"
				]
			},
			{
				name: "Gym",
				price: "₹4,999",
				note: "Member check-in",
				features: [
					"QR check-in flow",
					"Session / slot display",
					"Staff-friendly updates",
					"Works on any phone"
				]
			},
			{
				name: "Hotel",
				price: "₹3,999",
				note: "Room concierge",
				features: [
					"In-room guest concierge",
					"Services & requests",
					"Branded stay experience",
					"No app install needed"
				]
			},
			{
				name: "Academy",
				price: "₹4,999",
				note: "Student portal",
				features: [
					"Student / teacher views",
					"Notices board",
					"Availability status",
					"Simple admin updates"
				]
			},
			{
				name: "Salon",
				price: "₹999+",
				note: "Services & booking",
				features: [
					"Service menu & prices",
					"WhatsApp booking",
					"Easy daily updates",
					"Print-ready QR"
				]
			},
			{
				name: "Google Reviews",
				price: "₹1,500",
				note: "Review funnel",
				features: [
					"One-scan Google review",
					"Private feedback via WhatsApp",
					"Branded thank-you page",
					"Works for any shop"
				]
			},
			{
				name: "Social Media",
				price: "₹4,999–14,999/mo",
				note: "Monthly",
				features: [
					"Profile setup & grid",
					"Content calendar",
					"Post design",
					"Monthly reporting"
				]
			}
		]
	},
	{
		slug: "branding",
		code: "03",
		name: "Branding",
		short: "Logos, brand identity, Instagram setup and content that looks expensive.",
		summary: "A tight, premium look across your logo, colours, type and social — so every touchpoint feels like the same well-run business.",
		startingAt: "Quote",
		packages: [
			{
				name: "Logo Design",
				price: "Quote",
				note: "Mark + files",
				features: [
					"Concept options",
					"Primary + simplified mark",
					"PNG, SVG and print files",
					"Usage notes"
				]
			},
			{
				name: "Instagram Setup",
				price: "Quote",
				note: "Profile-ready",
				features: [
					"Profile photo & bio",
					"Highlight covers",
					"Grid starter pack",
					"Link in bio"
				]
			},
			{
				name: "Content Design",
				price: "Quote",
				note: "Posts & stories",
				features: [
					"Post templates",
					"Story layouts",
					"On-brand colour & type",
					"Editable source files"
				]
			}
		]
	}
];
var DEMO_GROUPS = [{
	id: "qr",
	label: "QR DEMOS"
}, {
	id: "website",
	label: "WEBSITE DEMOS"
}];
var DEMOS = [
	{
		slug: "restaurants",
		title: "Restaurant",
		subtitle: "QR Menu",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-restaurants/",
		icon: "utensils",
		group: "qr"
	},
	{
		slug: "gyms",
		title: "Gym",
		subtitle: "Check-in",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-gyms/",
		icon: "dumbbell",
		group: "qr"
	},
	{
		slug: "hotels",
		title: "Hotel",
		subtitle: "Concierge",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-hotels/",
		icon: "bed",
		group: "qr"
	},
	{
		slug: "academies",
		title: "Academy",
		subtitle: "Portal",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-academies/",
		icon: "graduation",
		group: "qr"
	},
	{
		slug: "salons",
		title: "Salon",
		subtitle: "Booking",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-salons/",
		icon: "scissors",
		group: "qr"
	},
	{
		slug: "reviews",
		title: "Reviews",
		subtitle: "Google Reviews",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-reviews/",
		icon: "star",
		group: "qr"
	},
	{
		slug: "social",
		title: "Social",
		subtitle: "Social Media",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-social/",
		icon: "share",
		group: "qr"
	},
	{
		slug: "hospital",
		title: "Hospital",
		subtitle: "Website",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-website-hospital/",
		icon: "hospital",
		group: "website"
	},
	{
		slug: "jewellery",
		title: "Jewellery",
		subtitle: "Website",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-website-jewellery/",
		icon: "gem",
		group: "website"
	},
	{
		slug: "hotel-website",
		title: "Hotel Website",
		subtitle: "Website",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-website-hotel/",
		icon: "building",
		group: "website"
	},
	{
		slug: "real-estate",
		title: "Real Estate",
		subtitle: "Website",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-website-realestate/",
		icon: "home",
		group: "website"
	},
	{
		slug: "car-dealer",
		title: "Car Dealer",
		subtitle: "Website",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-website-car-dealer/",
		icon: "car",
		group: "website"
	},
	{
		slug: "coaching",
		title: "Coaching",
		subtitle: "Website",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-website-coaching/",
		icon: "book",
		group: "website"
	},
	{
		slug: "gym-website",
		title: "Gym Website",
		subtitle: "Website",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-website-gym/",
		icon: "activity",
		group: "website"
	},
	{
		slug: "travel",
		title: "Travel",
		subtitle: "Website",
		url: "https://vikassharma01072008-prog.github.io/vaan-consultancy/demos/vaa-website-travel/",
		icon: "plane",
		group: "website"
	}
];
function serviceBySlug(slug) {
	return SERVICES.find((s) => s.slug === slug);
}
function demoBySlug(slug) {
	return DEMOS.find((d) => d.slug === slug);
}
//#endregion
export { INSTAGRAM_HANDLE as a, PHONE_DISPLAY as c, TAGLINE as d, WHATSAPP_URL as f, HOME_STATS as i, PHONE_TEL as l, serviceBySlug as m, DEMO_GROUPS as n, INSTAGRAM_URL as o, demoBySlug as p, HOME_DESCRIPTION as r, LOCATION as s, DEMOS as t, SERVICES as u };
