import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as MapPin, l as Phone, p as Instagram, u as MessageCircle } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-DUGEBN-o.mjs";
import { a as INSTAGRAM_HANDLE, c as PHONE_DISPLAY, f as WHATSAPP_URL, l as PHONE_TEL, o as INSTAGRAM_URL, s as LOCATION } from "./content-C5HRfteh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-DrPfPXPQ.js
var import_jsx_runtime = require_jsx_runtime();
function Contact() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex flex-1 flex-col px-5 pb-8 pt-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "rise font-display text-2xl font-extrabold tracking-brand text-gold",
				children: "GET IN TOUCH"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rise mt-3 flex items-center gap-2 text-sm leading-relaxed text-muted [animation-delay:80ms]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
					className: "size-4 shrink-0 text-gold",
					strokeWidth: 2
				}), LOCATION]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise mt-10 flex flex-col items-center [animation-delay:140ms]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-brand text-muted",
					children: "CALL"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `tel:${PHONE_TEL}`,
					className: "mt-2 font-display text-3xl font-extrabold tracking-wide text-gold",
					children: PHONE_DISPLAY
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise mt-10 flex flex-col gap-3 [animation-delay:200ms]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "whatsapp",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: WHATSAPP_URL,
							target: "_blank",
							rel: "noreferrer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
								className: "size-5",
								strokeWidth: 2.1
							}), "WhatsApp"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `tel:${PHONE_TEL}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "size-5",
									strokeWidth: 2.1
								}),
								"Call ",
								PHONE_DISPLAY
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: INSTAGRAM_URL,
							target: "_blank",
							rel: "noreferrer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {
								className: "size-5",
								strokeWidth: 2.1
							}), INSTAGRAM_HANDLE]
						})
					})
				]
			})
		]
	});
}
//#endregion
export { Contact as component };
