import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { v as ExternalLink, x as ChevronLeft } from "../_libs/lucide-react.mjs";
import { r as Route$1 } from "./router-CpsU1P_d.mjs";
import { t as Button } from "./button-DUGEBN-o.mjs";
import { p as demoBySlug } from "./content-C5HRfteh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/demos_._slug-RjK1bBEH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DemoViewer() {
	const { slug } = Route$1.useParams();
	const demo = demoBySlug(slug);
	const [loaded, setLoaded] = (0, import_react.useState)(false);
	if (!demo) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex flex-1 flex-col items-center justify-center gap-4 px-6 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "That demo is not available."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			size: "md",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/demos",
				children: "Back to demos"
			})
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col bg-navy",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex shrink-0 items-center gap-1 border-b border-line px-2 py-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/demos",
					"aria-label": "Back to demos",
					className: "flex size-11 items-center justify-center text-gold",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
						className: "size-6",
						strokeWidth: 2.2
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-semibold text-fg",
						children: demo.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-muted",
						children: demo.subtitle
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: demo.url,
					target: "_blank",
					rel: "noreferrer",
					"aria-label": "Open demo in a new tab",
					className: "flex size-11 items-center justify-center text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative min-h-0 flex-1 bg-navy-2",
			children: [!loaded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 flex items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm tracking-wide text-muted",
					children: "Loading demo…"
				})
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				src: demo.url,
				title: `${demo.title} live demo`,
				className: "h-full w-full border-0 bg-navy",
				onLoad: () => setLoaded(true),
				allow: "clipboard-write; fullscreen",
				referrerPolicy: "no-referrer-when-downgrade"
			})]
		})]
	});
}
//#endregion
export { DemoViewer as component };
