import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as ChevronRight } from "../_libs/lucide-react.mjs";
import { u as SERVICES } from "./content-C5HRfteh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-BJy6pp-C.js
var import_jsx_runtime = require_jsx_runtime();
function Services() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex flex-1 flex-col px-5 pb-8 pt-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "rise font-display text-2xl font-extrabold tracking-brand text-gold",
			children: "OUR SERVICES"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-7 flex flex-col gap-3.5",
			children: SERVICES.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "rise",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/services/$slug",
					params: { slug: service.slug },
					className: "flex min-h-24 items-center gap-4 rounded-xl bg-card px-5 py-4 shadow-card transition-transform duration-150 ease-out active:scale-[0.98]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-8 shrink-0 font-display text-lg font-bold tracking-wider text-gold",
							children: service.code
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-base font-semibold text-fg",
								children: service.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-sm leading-snug text-muted",
								children: service.short
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
							className: "size-5 shrink-0 text-gold",
							strokeWidth: 2.2
						})
					]
				})
			}, service.slug))
		})]
	});
}
//#endregion
export { Services as component };
