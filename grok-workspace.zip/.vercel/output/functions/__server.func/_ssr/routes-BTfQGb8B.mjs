import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-DUGEBN-o.mjs";
import { d as TAGLINE, i as HOME_STATS, r as HOME_DESCRIPTION } from "./content-C5HRfteh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BTfQGb8B.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex flex-1 flex-col px-6 pb-8 pt-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col items-center justify-center text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/vaan-logo.jpg",
					alt: "VAAN",
					width: 1008,
					height: 512,
					className: "rise w-[80%] max-w-xs object-contain"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "rise mt-4 font-display text-2xl font-extrabold tracking-brand text-gold [animation-delay:80ms]",
					children: "VAAN CONSULTANCY"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rise mt-3 max-w-xs text-sm font-medium tracking-label text-gold [animation-delay:140ms]",
					children: TAGLINE
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rise mt-4 max-w-sm text-sm leading-relaxed text-muted [animation-delay:180ms]",
					children: HOME_DESCRIPTION
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "rise mt-7 grid w-full grid-cols-3 gap-2 [animation-delay:220ms]",
					children: HOME_STATS.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "sr-only",
								children: stat.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-display text-lg font-bold tabular-nums text-gold",
								children: stat.value
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-0.5 text-xs tracking-wide text-muted",
								children: stat.label
							})
						]
					}, stat.label))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rise mt-8 [animation-delay:260ms]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/services",
					children: "Explore Services"
				})
			})
		})]
	});
}
//#endregion
export { Home as component };
