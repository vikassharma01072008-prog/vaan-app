//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-UlYYYSVy.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/contact",
			"/demos",
			"/services",
			"/demos_/$slug",
			"/services_/$slug"
		],
		preloads: [
			"/assets/index-DR-OKBvk.js",
			"/assets/jsx-runtime-Dk72oS4N.js",
			"/assets/preload-helper-DVUBt9c5.js",
			"/assets/link-BNdktEQP.js",
			"/assets/createLucideIcon-Ttm-HMR3.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DR-OKBvk.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-D2yAWh9j.js",
			"/assets/button-D2d1093o.js",
			"/assets/content-Cv_9yGX3.js"
		]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-CfUYcLo9.js",
			"/assets/button-D2d1093o.js",
			"/assets/content-Cv_9yGX3.js"
		]
	},
	"/demos": {
		filePath: "/workspace/src/routes/demos.tsx",
		children: void 0,
		preloads: ["/assets/demos-BOfoqMl3.js", "/assets/content-Cv_9yGX3.js"]
	},
	"/services": {
		filePath: "/workspace/src/routes/services.tsx",
		children: void 0,
		preloads: ["/assets/services-BqcUHBMx.js", "/assets/content-Cv_9yGX3.js"]
	},
	"/demos_/$slug": {
		filePath: "/workspace/src/routes/demos_.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/demos_._slug-CArQdE3p.js",
			"/assets/chevron-left-D4sYLPpC.js",
			"/assets/button-D2d1093o.js",
			"/assets/content-Cv_9yGX3.js"
		]
	},
	"/services_/$slug": {
		filePath: "/workspace/src/routes/services_.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/services_._slug-DLbRV6xZ.js",
			"/assets/chevron-left-D4sYLPpC.js",
			"/assets/button-D2d1093o.js",
			"/assets/content-Cv_9yGX3.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
