import { Link, useRouterState } from "@tanstack/react-router";
import { House, LayoutGrid, Play, User } from "lucide-react";
import { cn } from "@/lib/utils";

const TABS = [
  { to: "/", label: "Home", icon: House, match: (p: string) => p === "/" },
  {
    to: "/services",
    label: "Services",
    icon: LayoutGrid,
    match: (p: string) => p.startsWith("/services"),
  },
  {
    to: "/demos",
    label: "Demos",
    icon: Play,
    match: (p: string) => p.startsWith("/demos"),
  },
  {
    to: "/contact",
    label: "Contact",
    icon: User,
    match: (p: string) => p.startsWith("/contact"),
  },
] as const;

export function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav
      className="shrink-0 border-t border-line bg-navy pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1"
      aria-label="Main"
    >
      <ul className="grid grid-cols-4">
        {TABS.map((tab) => {
          const active = tab.match(pathname);
          const Icon = tab.icon;
          return (
            <li key={tab.to}>
              <Link
                to={tab.to}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "relative flex min-h-14 flex-col items-center justify-center gap-0.5 px-1 text-xs font-medium tracking-wide",
                  active ? "text-gold" : "text-muted",
                )}
              >
                <Icon
                  className="size-5"
                  strokeWidth={active ? 2.4 : 1.8}
                  fill={active && tab.label === "Home" ? "currentColor" : "none"}
                />
                <span>{tab.label}</span>
                <span
                  className={cn(
                    "absolute inset-x-6 bottom-0 h-0.5 rounded-full bg-gold transition-opacity duration-150",
                    active ? "opacity-100" : "opacity-0",
                  )}
                />
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
