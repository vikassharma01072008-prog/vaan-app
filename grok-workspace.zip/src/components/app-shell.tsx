import { useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { BottomNav } from "@/components/bottom-nav";
import { cn } from "@/lib/utils";

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isViewer = /^\/demos\/[^/]+$/.test(pathname);

  return (
    <div className="flex min-h-dvh justify-center bg-navy text-fg md:bg-navy-2">
      <div className="flex min-h-dvh w-full max-w-[430px] flex-col bg-navy md:min-h-[min(100dvh,860px)] md:border-x md:border-line">
        <div
          className={cn(
            "flex min-h-0 flex-1 flex-col",
            isViewer ? "overflow-hidden" : "overflow-y-auto",
          )}
        >
          {children}
        </div>
        {!isViewer ? <BottomNav /> : null}
      </div>
    </div>
  );
}
