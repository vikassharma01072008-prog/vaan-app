import {
  Activity,
  BedDouble,
  BookOpen,
  Building2,
  Car,
  Dumbbell,
  Gem,
  GraduationCap,
  Hospital,
  House,
  Plane,
  Scissors,
  Share2,
  Star,
  UtensilsCrossed,
} from "lucide-react";
import type { DemoIconName } from "@/lib/content";

const ICONS: Record<DemoIconName, typeof Star> = {
  utensils: UtensilsCrossed,
  dumbbell: Dumbbell,
  bed: BedDouble,
  scissors: Scissors,
  graduation: GraduationCap,
  star: Star,
  share: Share2,
  hospital: Hospital,
  gem: Gem,
  building: Building2,
  home: House,
  car: Car,
  book: BookOpen,
  activity: Activity,
  plane: Plane,
};

export function DemoIcon({
  name,
  className = "size-7",
}: {
  name: DemoIconName;
  className?: string;
}) {
  const Icon = ICONS[name];
  return <Icon className={className} strokeWidth={1.7} />;
}
