import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft, ExternalLink } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { demoBySlug } from "@/lib/content";

export const Route = createFileRoute("/demos_/$slug")({
  component: DemoViewer,
});

function DemoViewer() {
  const { slug } = Route.useParams();
  const demo = demoBySlug(slug);
  const [loaded, setLoaded] = useState(false);

  if (!demo) {
    return (
      <main className="flex flex-1 flex-col items-center justify-center gap-4 px-6 text-center">
        <p className="text-muted">That demo is not available.</p>
        <Button asChild size="md">
          <Link to="/demos">Back to demos</Link>
        </Button>
      </main>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col bg-navy">
      <header className="flex shrink-0 items-center gap-1 border-b border-line px-2 py-2">
        <Link
          to="/demos"
          aria-label="Back to demos"
          className="flex size-11 items-center justify-center text-gold"
        >
          <ChevronLeft className="size-6" strokeWidth={2.2} />
        </Link>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-fg">{demo.title}</p>
          <p className="truncate text-xs text-muted">{demo.subtitle}</p>
        </div>
        <a
          href={demo.url}
          target="_blank"
          rel="noreferrer"
          aria-label="Open demo in a new tab"
          className="flex size-11 items-center justify-center text-muted"
        >
          <ExternalLink className="size-4" />
        </a>
      </header>
      <div className="relative min-h-0 flex-1 bg-navy-2">
        {!loaded ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <p className="text-sm tracking-wide text-muted">Loading demo…</p>
          </div>
        ) : null}
        <iframe
          src={demo.url}
          title={`${demo.title} live demo`}
          className="h-full w-full border-0 bg-navy"
          onLoad={() => setLoaded(true)}
          allow="clipboard-write; fullscreen"
          referrerPolicy="no-referrer-when-downgrade"
        />
      </div>
    </div>
  );
}
