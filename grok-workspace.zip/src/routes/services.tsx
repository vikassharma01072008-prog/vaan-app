import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import { SERVICES } from "@/lib/content";

export const Route = createFileRoute("/services")({ component: Services });

function Services() {
  return (
    <main className="flex flex-1 flex-col px-5 pb-8 pt-10">
      <h1 className="rise font-display text-2xl font-extrabold tracking-brand text-gold">
        OUR SERVICES
      </h1>
      <ul className="mt-7 flex flex-col gap-3.5">
        {SERVICES.map((service) => (
          <li key={service.slug} className="rise">
            <Link
              to="/services/$slug"
              params={{ slug: service.slug }}
              className="flex min-h-24 items-center gap-4 rounded-xl bg-card px-5 py-4 shadow-card transition-transform duration-150 ease-out active:scale-[0.98]"
            >
              <span className="w-8 shrink-0 font-display text-lg font-bold tracking-wider text-gold">
                {service.code}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-base font-semibold text-fg">
                  {service.name}
                </span>
                <span className="mt-1 block text-sm leading-snug text-muted">
                  {service.short}
                </span>
              </span>
              <ChevronRight
                className="size-5 shrink-0 text-gold"
                strokeWidth={2.2}
              />
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
