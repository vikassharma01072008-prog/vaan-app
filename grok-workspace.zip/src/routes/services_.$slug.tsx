import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { serviceBySlug, WHATSAPP_URL } from "@/lib/content";

export const Route = createFileRoute("/services_/$slug")({
  component: ServiceDetail,
});

function ServiceDetail() {
  const { slug } = Route.useParams();
  const service = serviceBySlug(slug);

  if (!service) {
    return (
      <main className="flex flex-1 flex-col items-center justify-center gap-4 px-6 text-center">
        <p className="text-muted">That service is not listed.</p>
        <Button asChild size="md">
          <Link to="/services">Back to services</Link>
        </Button>
      </main>
    );
  }

  return (
    <main className="flex flex-1 flex-col px-5 pb-8 pt-4">
      <header className="flex items-center gap-1">
        <Link
          to="/services"
          aria-label="Back to services"
          className="flex size-11 items-center justify-center text-gold"
        >
          <ChevronLeft className="size-6" strokeWidth={2.2} />
        </Link>
        <h1 className="font-display text-xl font-extrabold tracking-brand text-gold">
          {service.name.toUpperCase()}
        </h1>
      </header>

      <p className="mt-4 text-sm leading-relaxed text-muted">{service.summary}</p>
      <p className="mt-3 text-sm font-medium text-gold">From {service.startingAt}</p>

      <ul className="mt-6 flex flex-col gap-3">
        {service.packages.map((pkg) => (
          <li key={pkg.name} className="rounded-xl bg-card px-5 py-4 shadow-card">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="text-base font-semibold text-fg">{pkg.name}</h2>
              <p className="shrink-0 text-right font-display text-base font-bold tabular-nums text-gold">
                {pkg.price}
              </p>
            </div>
            <p className="mt-0.5 text-xs font-medium tracking-wide text-muted">
              {pkg.note}
            </p>
            <ul className="mt-3 flex flex-col gap-1.5">
              {pkg.features.map((feature) => (
                <li
                  key={feature}
                  className="flex items-start gap-2 text-sm leading-snug text-fg"
                >
                  <Check
                    className="mt-0.5 size-3.5 shrink-0 text-gold"
                    strokeWidth={2.4}
                  />
                  {feature}
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>

      <div className="mt-6">
        <Button asChild>
          <a href={WHATSAPP_URL} target="_blank" rel="noreferrer">
            WhatsApp this service
          </a>
        </Button>
      </div>
    </main>
  );
}
