import { createFileRoute, Link } from "@tanstack/react-router";
import { DemoIcon } from "@/components/demo-icon";
import { DEMO_GROUPS, DEMOS } from "@/lib/content";

export const Route = createFileRoute("/demos")({ component: Demos });

function Demos() {
  return (
    <main className="flex flex-1 flex-col px-5 pb-8 pt-10">
      <h1 className="rise font-display text-2xl font-extrabold tracking-brand text-gold">
        LIVE DEMOS
      </h1>
      {DEMO_GROUPS.map((group) => (
        <section key={group.id} className="mt-7">
          <h2 className="text-xs font-semibold tracking-brand text-muted">
            {group.label}
          </h2>
          <ul className="mt-3 grid grid-cols-2 gap-3">
            {DEMOS.filter((demo) => demo.group === group.id).map((demo) => (
              <li key={demo.slug} className="rise">
                <Link
                  to="/demos/$slug"
                  params={{ slug: demo.slug }}
                  className="flex min-h-36 flex-col items-center justify-center gap-3 rounded-xl bg-card px-3 py-5 text-center shadow-card transition-transform duration-150 ease-out active:scale-[0.98]"
                >
                  <span className="flex size-12 items-center justify-center rounded-lg text-gold shadow-gold">
                    <DemoIcon name={demo.icon} />
                  </span>
                  <span>
                    <span className="block text-sm font-semibold text-gold">
                      {demo.title}
                    </span>
                    <span className="mt-0.5 block text-xs text-muted">
                      {demo.subtitle}
                    </span>
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ))}
    </main>
  );
}
