import { createFileRoute } from "@tanstack/react-router";
import { Instagram, MapPin, MessageCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  INSTAGRAM_HANDLE,
  INSTAGRAM_URL,
  LOCATION,
  PHONE_DISPLAY,
  PHONE_TEL,
  WHATSAPP_URL,
} from "@/lib/content";

export const Route = createFileRoute("/contact")({ component: Contact });

function Contact() {
  return (
    <main className="flex flex-1 flex-col px-5 pb-8 pt-10">
      <h1 className="rise font-display text-2xl font-extrabold tracking-brand text-gold">
        GET IN TOUCH
      </h1>
      <p className="rise mt-3 flex items-center gap-2 text-sm leading-relaxed text-muted [animation-delay:80ms]">
        <MapPin className="size-4 shrink-0 text-gold" strokeWidth={2} />
        {LOCATION}
      </p>

      <div className="rise mt-10 flex flex-col items-center [animation-delay:140ms]">
        <p className="text-xs font-medium tracking-brand text-muted">CALL</p>
        <a
          href={`tel:${PHONE_TEL}`}
          className="mt-2 font-display text-3xl font-extrabold tracking-wide text-gold"
        >
          {PHONE_DISPLAY}
        </a>
      </div>

      <div className="rise mt-10 flex flex-col gap-3 [animation-delay:200ms]">
        <Button asChild variant="whatsapp">
          <a href={WHATSAPP_URL} target="_blank" rel="noreferrer">
            <MessageCircle className="size-5" strokeWidth={2.1} />
            WhatsApp
          </a>
        </Button>
        <Button asChild variant="outline">
          <a href={`tel:${PHONE_TEL}`}>
            <Phone className="size-5" strokeWidth={2.1} />
            Call {PHONE_DISPLAY}
          </a>
        </Button>
        <Button asChild variant="outline">
          <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer">
            <Instagram className="size-5" strokeWidth={2.1} />
            {INSTAGRAM_HANDLE}
          </a>
        </Button>
      </div>
    </main>
  );
}
