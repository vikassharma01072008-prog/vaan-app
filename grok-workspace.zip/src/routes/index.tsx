import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { HOME_DESCRIPTION, HOME_STATS, TAGLINE } from "@/lib/content";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="flex flex-1 flex-col px-6 pb-8 pt-8">
      <div className="flex flex-1 flex-col items-center justify-center text-center">
        <img
          src="/vaan-logo.jpg"
          alt="VAAN"
          width={1008}
          height={512}
          className="rise w-[80%] max-w-xs object-contain"
        />
        <h1 className="rise mt-4 font-display text-2xl font-extrabold tracking-brand text-gold [animation-delay:80ms]">
          VAAN CONSULTANCY
        </h1>
        <p className="rise mt-3 max-w-xs text-sm font-medium tracking-label text-gold [animation-delay:140ms]">
          {TAGLINE}
        </p>
        <p className="rise mt-4 max-w-sm text-sm leading-relaxed text-muted [animation-delay:180ms]">
          {HOME_DESCRIPTION}
        </p>
        <dl className="rise mt-7 grid w-full grid-cols-3 gap-2 [animation-delay:220ms]">
          {HOME_STATS.map((stat) => (
            <div key={stat.label} className="text-center">
              <dt className="sr-only">{stat.label}</dt>
              <dd className="font-display text-lg font-bold tabular-nums text-gold">
                {stat.value}
              </dd>
              <p className="mt-0.5 text-xs tracking-wide text-muted">{stat.label}</p>
            </div>
          ))}
        </dl>
      </div>
      <div className="rise mt-8 [animation-delay:260ms]">
        <Button asChild>
          <Link to="/services">Explore Services</Link>
        </Button>
      </div>
    </main>
  );
}
